親手訓練一個小 LLM：Python 範例

需要 Python 3.9 以上與 PyTorch（pip install torch）。

1. python prepare_data.py   下載《全唐詩》（chinese-poetry 專案，MIT 授權），產生 data/tang.txt
2. python train.py          訓練，產生 ckpt.pt 與 tokenizer.json
3. python sample.py --prompt 春
4. python chat.py
5. python s13_instruct_data.py && python lora.py && python s14_eval.py   LoRA 指令微調與評估

hf_qwen_lora.py 另外需要 pip install transformers peft，並可連線 Hugging Face。
