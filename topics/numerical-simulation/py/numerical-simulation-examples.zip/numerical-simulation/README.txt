用 Python 做數值模擬：課程範例

需要 Python 3.9 以上：pip install numpy scipy matplotlib（numba 可選）。
每支程式都可以單獨執行：python 檔名.py

蝕刻腔：先 python chamber_lbm.py（產生 chamber_flow.npz），再 python chamber_species.py；chamber_design.py 會自己重算流場。
互動水池：python pool_live.py（有螢幕時會開視窗，點水面滴水）。
