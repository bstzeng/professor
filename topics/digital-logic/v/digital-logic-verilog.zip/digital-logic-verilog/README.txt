數位邏輯設計：Verilog 範例

需要 Icarus Verilog 12（iverilog、vvp）與 Python 3。
  Linux：apt install iverilog    macOS：brew install icarus-verilog    Windows：bleyer.org/icarus

執行全部範例：sh run_all.sh
輸出會寫到 _out/<名稱>.txt，與課程頁面上的模擬結果相同。

單獨執行一個範例，例如：
  iverilog -g2012 -o adders tb_adders.v adders.v && vvp adders

RISC-V CPU：
  python3 asm.py prog.s prog.hex
  iverilog -g2012 -o rv tb_rv_single.v rv_single.v regfile.v alu.v && vvp rv
