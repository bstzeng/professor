Agentic AI 的運行原理：Python 範例

離線版（本資料夾）：python a01_chat_vs_agent.py
  需要 Python 3.9 以上；mockllm.py 是模仿 Anthropic SDK 介面的假 LLM，不需 API 金鑰、不需網路。

Claude API 版（claude/ 資料夾）：
  pip install anthropic
  export ANTHROPIC_API_KEY=你的金鑰
  python claude/a01_chat_vs_agent.py
  會實際呼叫 Claude API 並計費。API 細節以 Anthropic 官方文件為準。
